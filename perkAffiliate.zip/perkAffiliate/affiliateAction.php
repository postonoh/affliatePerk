<?php

function Save()
{
    global $wpdb;
    $table_name = $wpdb->prefix.'affiliatePerks';
    $clientname = $_POST['clientname'];
    $clientcode = $_POST['clientcode'];

 if( isset( $_POST['save'] ) ) {	 

    echo '<script language="javascript">';
    echo 'alert("message successfully sent")';
    echo '</script>';   

     $result = $wpdb->insert( 
         $table_name, 
         array( 				 
             'clientName' => $clientname, 
             'clientCode' => $clientcode, 
         ), 
         array( 
             '%s', 
             '%s' 
         ) 
     );	 
 }
}

function Delete()
{
 if( isset( $_POST['delete'] ) ) {
 $clientname = $_POST['clientname'];
 $clientcode = $_POST['clientcode'];

 global $wpdb;
    if(is_user_logged_in())
    {

     $table_name = $wpdb->prefix . 'affiliatePerks';

     $wpdb->insert( 
         $table_name, 
         array( 				 
             'clientName' => $clientname, 
             'clientCode' => $clientcode, 
         ) 
     );
    }
 }
}
?>