$(document).ready(function () {

    $('#affiliateperks-admin-save').click(function() {

    });

});