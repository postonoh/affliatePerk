$(document).ready(function () {



   $('#tblAffiliate').DataTable({
    "dom": '<"top"B>rt<"bottom"lip><"clear">',
    buttons:
        [{
            extend: 'excelHtml5',
            text: 'Save current page',
            exportOptions: {
                modifier: {
                    page: 'current'
                }
            
            }
        }],
   });


    $('#affiliateperks-admin-edit').click(function () {
        AffiliateLoadEdit();
    });
    $('#affiliateperks-admin-delete').click(function () {
        alert("Deleting");
       // AffiliateLoadDelete();
    });



    function AffiliateLoadClientsCode() {   
        debugger;     
        $.ajax({
            type: "post",
            dataType: 'json',
            url: myAffiliateAjax.ajaxurl,
            data: {
                action: 'GetAffiliateList'
            },
            success: function (result) {
                
                dataSet = JSON.parse(result.d);
                $('#tblAffiliate').DataTable().destroy();
                $('#tblAffiliate').DataTable({
                    dom: 'Bfrtip',
                    "info": false,
                   "searching": false,
                    buttons: [
                        'excel'
                    ],
                    "data": dataSet,
                    columns: [
                        
                        { data: 'clientName', className: 'clientname' },
                        { data: 'clientCode', className: 'clientcode' }

                    ],
                    createdRow: function (nRow, aData, iDataIndex) {
                        $(nRow).attr('data-Id', aData.affiliateperks_id);
                    }

                });
            }

        });
    }

});